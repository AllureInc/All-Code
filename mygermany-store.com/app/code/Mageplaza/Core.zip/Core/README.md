## Mageplaza Core M2
