<?php
    /**
     * Webkul Walletsystem Registration
     *
     * @category    Webkul
     * @package     Webkul_Walletsystem
     * @author      Webkul Software Private Limited
     *
     */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Webkul_Walletsystem',
    __DIR__
);
