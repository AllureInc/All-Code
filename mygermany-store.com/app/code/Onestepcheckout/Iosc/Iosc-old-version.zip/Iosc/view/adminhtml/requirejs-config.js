var config = {
    map: {
        '*': {
            onestepcheckoutIosc: 'Onestepcheckout_Iosc/js/iosc-app'
        }
    }
};
